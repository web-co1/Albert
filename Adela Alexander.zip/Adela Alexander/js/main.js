// all variables
const testimonialSlider = document.querySelector(".testimonials__slider");
const menuBtn = document.querySelector(".menu-btn");

/* testimonials slider starts from here */
if(testimonialSlider){
 $('.testimonials__slider').slick({
    infinite: true,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 1,
    arrows: true,
    prevArrow: '<button class="slide-arrows prev"><img src="assets/prev-arrow.svg" alt="arrow"></button>',
    nextArrow: '<button class="slide-arrows nxt"><img src="assets/nxt-arrow.svg" alt="arrow"></button>',
    responsive: [
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
          arrows: false,
          autoplay: true,
          autoplaySpeed: 3000,
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
          arrows: false,
          autoplay: true,
          autoplaySpeed: 3000,
        }
      }
    ]
  });
}
/* --- testimonials slider starts from here --- */

/* navigation menu starts from here */
if(menuBtn){
  menuBtn.addEventListener("click", (e) => {
    e.stopPropagation(); 
    document.body.classList.toggle("is_open");
  });
  
  window.addEventListener("click", () => {
    if (document.body.classList.contains("is_open")) {
      document.body.classList.remove("is_open");
    }
  });
}